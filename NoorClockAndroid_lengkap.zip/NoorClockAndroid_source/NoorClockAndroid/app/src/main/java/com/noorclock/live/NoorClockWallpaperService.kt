package com.noorclock.live

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NoorClockWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = NoorEngine()

    inner class NoorEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private var surfaceWidth = 0
        private var surfaceHeight = 0
        private val bitmap by lazy {
            BitmapFactory.decodeResource(resources, R.drawable.mosque_night)
        }

        private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val shadePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(82, 0, 4, 14)
        }
        private val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(218, 247, 255)
            textAlign = Paint.Align.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
            setShadowLayer(14f, 0f, 0f, Color.rgb(48, 174, 255))
        }
        private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(221, 234, 247)
            textAlign = Paint.Align.CENTER
            textSize = 28f
            letterSpacingCompat(1.8f)
        }
        private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 239, 203)
            textAlign = Paint.Align.CENTER
            textSize = 45f
        }
        private val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(220, 230, 242, 255)
            textAlign = Paint.Align.CENTER
            textSize = 22f
        }

        private val drawRunnable = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 1000L)
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            handler.removeCallbacks(drawRunnable)
            if (visible) handler.post(drawRunnable)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceWidth = width
            surfaceHeight = height
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(drawRunnable)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            handler.removeCallbacks(drawRunnable)
            super.onDestroy()
        }

        private fun drawFrame() {
            val holder: SurfaceHolder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) drawWallpaper(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun drawWallpaper(canvas: Canvas) {
            val w = canvas.width.toFloat()
            val h = canvas.height.toFloat()
            canvas.drawColor(Color.rgb(4, 9, 19))

            val bmp = bitmap
            val scale = maxOf(w / bmp.width, h / bmp.height)
            val dw = bmp.width * scale
            val dh = bmp.height * scale
            val left = (w - dw) / 2f
            val top = (h - dh) / 2f
            canvas.drawBitmap(bmp, null, Rect(left.toInt(), top.toInt(), (left + dw).toInt(), (top + dh).toInt()), backgroundPaint)
            canvas.drawRect(0f, 0f, w, h, shadePaint)

            val now = Date()
            val time24 = SimpleDateFormat("HH:mm", Locale.US).format(now)
            val seconds = SimpleDateFormat("ss", Locale.US).format(now)
            val arabicTime = toArabicDigits(time24)
            val arabicSeconds = toArabicDigits(seconds)
            val date = SimpleDateFormat("EEE، d MMM yyyy", Locale("id", "ID")).format(now).uppercase(Locale("id", "ID"))

            val centerX = w / 2f
            val clockY = h * 0.23f
            labelPaint.textSize = (w * 0.055f).coerceIn(28f, 48f)
            datePaint.textSize = (w * 0.027f).coerceIn(18f, 30f)
            timePaint.textSize = (w * 0.19f).coerceIn(76f, 142f)
            footerPaint.textSize = (w * 0.022f).coerceIn(15f, 23f)

            canvas.drawText("مساء النور", centerX, clockY - timePaint.textSize * 1.08f, labelPaint)
            canvas.drawText(date, centerX, clockY - timePaint.textSize * 0.62f, datePaint)
            canvas.drawText(arabicTime, centerX, clockY + timePaint.textSize * 0.10f, timePaint)

            val secPaint = Paint(timePaint).apply {
                textSize = timePaint.textSize * 0.28f
                clearShadowLayer()
            }
            canvas.drawText(arabicSeconds, centerX + timePaint.textSize * 1.15f, clockY - timePaint.textSize * 0.48f, secPaint)
            canvas.drawText("NOOR CLOCK", centerX, h * 0.94f, footerPaint)
        }

        private fun toArabicDigits(value: String): String {
            val digits = charArrayOf('٠','١','٢','٣','٤','٥','٦','٧','٨','٩')
            return value.map { c -> if (c in '0'..'9') digits[c - '0'] else c }.joinToString("")
        }

        private fun Paint.letterSpacingCompat(value: Float) {
            // Canvas Paint has no letterSpacing property; visual spacing is handled by the typeface and alignment.
        }
    }
}
