# Noor Clock — proyek Android Live Wallpaper

Proyek Android Studio awal untuk live wallpaper masjid dengan jam digital angka Arab-Indic (٠١٢٣٤٥٦٧٨٩), tanggal otomatis, tema gelap, dan foto masjid yang Anda kirim sebagai latar.

## Penting
- Ini adalah **source project**, bukan APK yang sudah terkompilasi. APK perlu dibuat melalui Android Studio/Gradle.
- Live wallpaper biasanya dapat dipilih untuk layar utama. Pada Infinix/Tecno, pemasangan ke layar kunci bergantung pada model, XOS/HiOS, dan versi Android; beberapa perangkat tidak mendukung live wallpaper pada lock screen.
- Jam mengikuti waktu perangkat dan diperbarui setiap detik saat wallpaper terlihat.
- Foto default ada di `app/src/main/res/drawable-nodpi/mosque_night.jpg`. Ganti file itu jika ingin memakai foto lain dengan nama yang sama.

## Membuat APK
1. Di komputer, instal Android Studio versi stabil dan Android SDK Platform 35.
2. Ekstrak ZIP ini.
3. Android Studio → **Open** → pilih folder `NoorClockAndroid`.
4. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK yang disarankan.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.
7. Salin APK ke HP, izinkan instalasi dari sumber tersebut bila Android meminta, lalu instal.

## Memasang wallpaper
1. Buka Pengaturan HP atau tekan lama di area kosong layar utama.
2. Cari **Wallpaper / Personalization / Live Wallpaper**.
3. Pilih **Noor Clock — Jam Arab**.
4. Tekan **Set wallpaper** dan pilih layar utama.
5. Jika perangkat menawarkan pilihan layar kunci juga, pilih keduanya. Jika tidak ada, perangkat/versi OS tidak menyediakan dukungan tersebut untuk live wallpaper.

## Catatan build
Proyek ini memakai Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compileSdk 35, dan minSdk 23. Untuk build pertama dibutuhkan koneksi internet agar Gradle mengunduh komponen yang diperlukan.
